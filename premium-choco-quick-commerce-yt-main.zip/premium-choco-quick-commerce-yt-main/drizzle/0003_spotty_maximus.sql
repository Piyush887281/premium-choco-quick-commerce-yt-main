ALTER TABLE "warehouses" ADD COLUMN "updated_at" timestamp DEFAULT CURRENT_TIMESTAMP;--> statement-breakpoint
ALTER TABLE "warehouses" ADD COLUMN "created_at" timestamp DEFAULT CURRENT_TIMESTAMP;